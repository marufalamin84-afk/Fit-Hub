import { useState } from 'react';
import { ShoppingCart, Menu, X, Check, Star, Phone, Mail, MapPin, Facebook, Instagram, Twitter } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { toast } from 'sonner';
import './App.css';

interface Product {
  id: number;
  name: string;
  price: number;
  originalPrice?: number;
  image: string;
  features: string[];
  sizes: string[];
}

interface CartItem {
  product: Product;
  size: string;
  quantity: number;
}

const products: Product[] = [
  {
    id: 1,
    name: 'প্রো কম্প্রেশন ব্ল্যাক',
    price: 1299,
    image: '/images/black-compression.jpg',
    features: ['ময়েশ্চার-উইকিং', '৪-ওয়ে স্ট্রেচ'],
    sizes: ['S', 'M', 'L', 'XL', 'XXL']
  },
  {
    id: 2,
    name: 'প্রো কম্প্রেশন নেভি',
    price: 1199,
    image: '/images/navy-compression.jpg',
    features: ['এন্টি-ব্যাকটেরিয়াল', 'উন্নত ব্রিথেবিলিটি'],
    sizes: ['S', 'M', 'L', 'XL', 'XXL']
  }
];

function App() {
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [selectedSizes, setSelectedSizes] = useState<Record<number, string>>({});

  const addToCart = (product: Product) => {
    const size = selectedSizes[product.id];
    if (!size) {
      toast.error('অনুগ্রহ করে সাইজ নির্বাচন করুন');
      return;
    }

    const existingItem = cart.find(item => item.product.id === product.id && item.size === size);
    
    if (existingItem) {
      setCart(cart.map(item => 
        item.product.id === product.id && item.size === size
          ? { ...item, quantity: item.quantity + 1 }
          : item
      ));
    } else {
      setCart([...cart, { product, size, quantity: 1 }]);
    }
    
    toast.success('প্রোডাক্ট কার্টে যোগ হয়েছে!');
  };

  const removeFromCart = (productId: number, size: string) => {
    setCart(cart.filter(item => !(item.product.id === productId && item.size === size)));
  };

  const getTotalPrice = () => {
    return cart.reduce((total, item) => total + item.product.price * item.quantity, 0);
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-sm z-50 border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <span className="text-2xl font-bold text-gray-900">FIT<span className="text-red-600">GEAR</span></span>
            </div>
            
            {/* Desktop Menu */}
            <div className="hidden md:flex items-center space-x-8">
              <button onClick={() => scrollToSection('home')} className="text-gray-700 hover:text-red-600 transition">হোম</button>
              <button onClick={() => scrollToSection('products')} className="text-gray-700 hover:text-red-600 transition">প্রোডাক্টস</button>
              <button onClick={() => scrollToSection('size-guide')} className="text-gray-700 hover:text-red-600 transition">সাইজ গাইড</button>
              <button onClick={() => scrollToSection('contact')} className="text-gray-700 hover:text-red-600 transition">যোগাযোগ</button>
            </div>

            <div className="flex items-center space-x-4">
              <button 
                onClick={() => setIsCartOpen(true)}
                className="relative p-2 text-gray-700 hover:text-red-600 transition"
              >
                <ShoppingCart className="w-6 h-6" />
                {cart.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-600 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">
                    {cart.reduce((sum, item) => sum + item.quantity, 0)}
                  </span>
                )}
              </button>
              
              <button 
                className="md:hidden p-2"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMobileMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <div className="px-4 py-4 space-y-3">
              <button onClick={() => scrollToSection('home')} className="block w-full text-left py-2 text-gray-700">হোম</button>
              <button onClick={() => scrollToSection('products')} className="block w-full text-left py-2 text-gray-700">প্রোডাক্টস</button>
              <button onClick={() => scrollToSection('size-guide')} className="block w-full text-left py-2 text-gray-700">সাইজ গাইড</button>
              <button onClick={() => scrollToSection('contact')} className="block w-full text-left py-2 text-gray-700">যোগাযোগ</button>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="pt-16 relative h-[600px] flex items-center">
        <div className="absolute inset-0">
          <img 
            src="/images/hero-compression.jpg" 
            alt="Compression T-Shirt" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/50"></div>
        </div>
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-white">
          <h1 className="text-4xl md:text-6xl font-bold mb-4">
            পেশাদারি অ্যাথলেটিক<br />পারফরম্যান্স ওয়্যার
          </h1>
          <p className="text-xl md:text-2xl mb-8 text-gray-200">
            সর্বোচ্চ মানের কম্প্রেশন টেকনোলজি
          </p>
          <Button 
            onClick={() => scrollToSection('products')}
            className="bg-red-600 hover:bg-red-700 text-white px-8 py-6 text-lg"
          >
            শপিং শুরু করুন
          </Button>
        </div>
      </section>

      {/* Collection Banner */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-gray-600 mb-2">আমাদের কালেকশন</p>
          <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            কম্প্রেশন<br />টি-শার্ট
          </h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            আপনার ট্রেনিং এর জন্য সেরা মানের কম্প্রেশন ওয়্যার
          </p>
        </div>
      </section>

      {/* Products Section */}
      <section id="products" className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">বেস্ট সেলার</h2>
          
          <div className="grid md:grid-cols-2 gap-8">
            {products.map((product) => (
              <div key={product.id} className="bg-white rounded-lg shadow-lg overflow-hidden border">
                <div className="aspect-[3/4] bg-gray-100">
                  <img 
                    src={product.image} 
                    alt={product.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-xl font-bold mb-2">{product.name}</h3>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {product.features.map((feature, idx) => (
                      <span key={idx} className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-sm">
                        {feature}
                      </span>
                    ))}
                  </div>
                  
                  <p className="text-sm text-gray-600 mb-3">সাইজ নির্বাচন করুন</p>
                  <div className="flex gap-2 mb-4">
                    {product.sizes.map((size) => (
                      <button
                        key={size}
                        onClick={() => setSelectedSizes({ ...selectedSizes, [product.id]: size })}
                        className={`w-10 h-10 rounded border-2 font-medium transition ${
                          selectedSizes[product.id] === size
                            ? 'border-red-600 bg-red-600 text-white'
                            : 'border-gray-300 hover:border-red-600'
                        }`}
                      >
                        {size}
                      </button>
                    ))}
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-gray-500 text-sm">শুরু</span>
                      <p className="text-2xl font-bold text-red-600">৳{product.price}</p>
                    </div>
                    <Button 
                      onClick={() => addToCart(product)}
                      className="bg-red-600 hover:bg-red-700 text-white px-6"
                    >
                      কার্টে যোগ করুন
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Featured Product */}
      <section className="py-16 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-8">
            <p className="text-red-500 font-medium">FITGEAR</p>
            <h2 className="text-3xl font-bold">ফিচার্ড প্রোডাক্ট</h2>
          </div>
          
          <div className="bg-gray-800 rounded-2xl p-8 md:p-12 flex flex-col md:flex-row items-center gap-8">
            <div className="flex-1">
              <span className="bg-red-600 text-white px-4 py-1 rounded-full text-sm">প্রো সিরিজ</span>
              <h3 className="text-3xl font-bold mt-4 mb-2">প্রো কম্প্রেশন ব্ল্যাক</h3>
              <p className="text-gray-400 mb-6">
                প্রিমিয়াম কোয়ালিটি ব্ল্যাক কম্প্রেশন টি-শার্ট। ময়েশ্চার-উইকিং টেকনোলজি সহ ৪-ওয়ে স্ট্রেচ ফ্যাব্রিক।
              </p>
              <p className="text-3xl font-bold text-red-500">৳১,২৯৯</p>
            </div>
            <div className="flex-1">
              <img 
                src="/images/black-compression.jpg" 
                alt="Pro Compression Black"
                className="rounded-lg w-full max-w-md mx-auto"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Size Guide */}
      <section id="size-guide" className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-8">সাইজ গাইড</h2>
          
          <div className="bg-white rounded-lg shadow overflow-hidden">
            <table className="w-full">
              <thead className="bg-gray-900 text-white">
                <tr>
                  <th className="px-6 py-4 text-left">সাইজ</th>
                  <th className="px-6 py-4 text-left">চেস্ট (ইঞ্চি)</th>
                  <th className="px-6 py-4 text-left">লেংথ (ইঞ্চি)</th>
                </tr>
              </thead>
              <tbody>
                {[
                  { size: 'S', chest: '36-38', length: '26' },
                  { size: 'M', chest: '38-40', length: '27' },
                  { size: 'L', chest: '40-42', length: '28' },
                  { size: 'XL', chest: '42-44', length: '29' },
                  { size: 'XXL', chest: '44-46', length: '30' },
                ].map((row, idx) => (
                  <tr key={idx} className={idx % 2 === 0 ? 'bg-gray-50' : 'bg-white'}>
                    <td className="px-6 py-4 font-medium">{row.size}</td>
                    <td className="px-6 py-4">{row.chest}</td>
                    <td className="px-6 py-4">{row.length}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          
          <div className="mt-6 bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-blue-800 text-sm">
              <strong>টিপ:</strong> কম্প্রেশন ফিটের জন্য আপনার নিয়মিত সাইজের এক সাইজ ছোট নিতে পারেন।
            </p>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">কেন FITGEAR?</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { title: 'ময়েশ্চার-উইকিং', desc: 'ঘাম দ্রুত শুকিয়ে আপনাকে শীতল রাখে' },
              { title: '৪-ওয়ে স্ট্রেচ', desc: 'সর্বোচ্চ নমনীয়তা ও কম্ফোর্ট' },
              { title: 'এন্টি-ব্যাকটেরিয়াল', desc: 'দুর্গন্ধ প্রতিরোধী টেকনোলজি' },
            ].map((feature, idx) => (
              <div key={idx} className="text-center p-6">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Check className="w-8 h-8 text-red-600" />
                </div>
                <h3 className="text-xl font-bold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">গ্রাহকদের মতামত</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { name: 'রাহুল হোসেন', text: 'খুবই ভালো কোয়ালিটি। জিমে ব্যবহার করতে দারুণ লাগে।', rating: 5 },
              { name: 'সাদিয়া আক্তার', text: 'আমার ভাইয়ের জন্য কিনেছিলাম, ও খুব পছন্দ করেছে।', rating: 5 },
              { name: 'করিম মিয়া', text: 'দাম অনুযায়ী কোয়ালিটি অসাধারণ। আবার কিনবো।', rating: 4 },
            ].map((review, idx) => (
              <div key={idx} className="bg-white p-6 rounded-lg shadow">
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star 
                      key={i} 
                      className={`w-5 h-5 ${i < review.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'}`} 
                    />
                  ))}
                </div>
                <p className="text-gray-600 mb-4">"{review.text}"</p>
                <p className="font-medium">- {review.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact */}
      <section id="contact" className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-center mb-12">যোগাযোগ</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            <div className="flex items-center gap-4 p-6 bg-gray-50 rounded-lg">
              <Phone className="w-8 h-8 text-red-600" />
              <div>
                <p className="font-medium">ফোন</p>
                <p className="text-gray-600">+880 1234-567890</p>
              </div>
            </div>
            <div className="flex items-center gap-4 p-6 bg-gray-50 rounded-lg">
              <Mail className="w-8 h-8 text-red-600" />
              <div>
                <p className="font-medium">ইমেইল</p>
                <p className="text-gray-600">info@fitgear.bd</p>
              </div>
            </div>
            <div className="flex items-center gap-4 p-6 bg-gray-50 rounded-lg">
              <MapPin className="w-8 h-8 text-red-600" />
              <div>
                <p className="font-medium">ঠিকানা</p>
                <p className="text-gray-600">ঢাকা, বাংলাদেশ</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <h3 className="text-2xl font-bold mb-4">FIT<span className="text-red-600">GEAR</span></h3>
              <p className="text-gray-400">পেশাদারি অ্যাথলেটিক পারফরম্যান্স ওয়্যার</p>
            </div>
            <div>
              <h4 className="font-bold mb-4">দ্রুত লিংক</h4>
              <ul className="space-y-2 text-gray-400">
                <li><button onClick={() => scrollToSection('home')} className="hover:text-white">হোম</button></li>
                <li><button onClick={() => scrollToSection('products')} className="hover:text-white">প্রোডাক্টস</button></li>
                <li><button onClick={() => scrollToSection('size-guide')} className="hover:text-white">সাইজ গাইড</button></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">সাপোর্ট</h4>
              <ul className="space-y-2 text-gray-400">
                <li><button onClick={() => scrollToSection('contact')} className="hover:text-white">যোগাযোগ</button></li>
                <li><span className="hover:text-white">রিটার্ন পলিসি</span></li>
                <li><span className="hover:text-white">শিপিং তথ্য</span></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold mb-4">সোশ্যাল মিডিয়া</h4>
              <div className="flex gap-4">
                <Facebook className="w-6 h-6 text-gray-400 hover:text-white cursor-pointer" />
                <Instagram className="w-6 h-6 text-gray-400 hover:text-white cursor-pointer" />
                <Twitter className="w-6 h-6 text-gray-400 hover:text-white cursor-pointer" />
              </div>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>© 2024 FITGEAR. সর্বস্বত্ব সংরক্ষিত।</p>
          </div>
        </div>
      </footer>

      {/* Cart Dialog */}
      <Dialog open={isCartOpen} onOpenChange={setIsCartOpen}>
        <DialogContent className="max-w-md max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShoppingCart className="w-5 h-5" />
              আপনার কার্ট
            </DialogTitle>
          </DialogHeader>
          
          {cart.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              কার্ট খালি
            </div>
          ) : (
            <div className="space-y-4">
              {cart.map((item, idx) => (
                <div key={idx} className="flex items-center gap-4 p-4 bg-gray-50 rounded-lg">
                  <img 
                    src={item.product.image} 
                    alt={item.product.name}
                    className="w-16 h-16 object-cover rounded"
                  />
                  <div className="flex-1">
                    <h4 className="font-medium">{item.product.name}</h4>
                    <p className="text-sm text-gray-600">সাইজ: {item.size}</p>
                    <p className="text-sm text-gray-600">পরিমাণ: {item.quantity}</p>
                    <p className="font-bold text-red-600">৳{item.product.price * item.quantity}</p>
                  </div>
                  <button 
                    onClick={() => removeFromCart(item.product.id, item.size)}
                    className="text-red-600 hover:text-red-700"
                  >
                    <X className="w-5 h-5" />
                  </button>
                </div>
              ))}
              
              <div className="border-t pt-4">
                <div className="flex justify-between items-center mb-4">
                  <span className="font-bold">মোট:</span>
                  <span className="text-xl font-bold text-red-600">৳{getTotalPrice()}</span>
                </div>
                <Button 
                  className="w-full bg-red-600 hover:bg-red-700"
                  onClick={() => {
                    toast.success('অর্ডার কনফার্ম হয়েছে!');
                    setCart([]);
                    setIsCartOpen(false);
                  }}
                >
                  চেকআউট
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

export default App;
